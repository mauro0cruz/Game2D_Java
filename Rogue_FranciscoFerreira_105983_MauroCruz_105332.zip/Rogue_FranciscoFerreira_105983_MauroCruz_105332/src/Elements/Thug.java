package Elements;

import Others.GameElement;
import Others.Monster;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Thug extends Monster{
	
	static private final int hp = 10;
	static private final int dmg = 3;
	static private final int score= 8;

	
	static final int layer = 3;

	public Thug(Point2D position) {
		super(position, hp, dmg);
	}

	@Override
	public int getLayer() {
		return layer;
	}

	@Override
	public String getName() {
		return "Thug";
	}

	@Override
	public Direction getDirection(GameElement g) {
		return super.getDirection(g);
	}

	@Override
	protected void giveDamage(Point2D p, Hero h) { 
		double random = Math.random();
		
		if(random <= 0.3)										// so da dano 30% das vezes que ataca
			super.giveDamage(p, h);
	}
	
	
	@Override
	public int getScore() {
		return score;
	}

}
