package Elements;

import Others.Monster;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Skeleton extends Monster{
	
	static private final int hp = 5;
	static private final int dmg = 1;
	private boolean turnMove = false;					// para se mover de 2 em 2 turnos
	static private final int score= 4;
	
	static final int layer = 3;
	
	
	public Skeleton(Point2D position) {
		super(position, hp, dmg);
	}

	@Override
	public int getLayer() {
		return layer;
	}

	@Override
	public String getName() {
		return "Skeleton";
	}
	
	@Override
	public void move(Direction direction) {
		if(turnMove)
			super.move(direction);
		
		turnMove = !turnMove;
	}

	@Override
	public int getScore() {
		return score;
	}
}
