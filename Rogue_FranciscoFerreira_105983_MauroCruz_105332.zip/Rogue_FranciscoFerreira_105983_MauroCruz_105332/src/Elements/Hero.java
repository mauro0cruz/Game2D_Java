package Elements;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import Engine.Jogo;
import Items.HealingPotion;
import Map.Elements.Door;
import Map.Elements.Wall;
import Others.GameElement;
import Others.Inventory;
import Others.Item;
import Others.LoadRoom;
import Others.MElement;
import Others.Monster;
import pt.iscte.poo.gui.ImageMatrixGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public class Hero extends MElement {
	
	static private final int hp = 10;
	static private final int dmg = 1;
	static private final int poisondmg = 1;
	
	static final int layer = 3;
	
	private Inventory inv;
	private boolean hasArmor;
	private boolean hasSword;
	private boolean isPoison = false;
	
	public Hero(Point2D position) {
		super(position, hp, dmg);
		this.inv = new Inventory();
		hasArmor = hasSword = false;
	}
	
	@Override
	public String getName() {
		return "Hero";
	}
	
	@Override
	public int getLayer() {
		return layer;
	}
	
	
	@Override
	public void move(Direction direction) {	
		LoadRoom lr = Jogo.getInstance().getLr();
		Vector2D Vector = direction.asVector();
		Point2D p = getPosition().plus(Vector);
		
		Predicate<GameElement> isWall = g -> g instanceof Wall && g.getPosition().equals(p);
		Predicate<GameElement> isMonster = g -> g instanceof Monster && g.getPosition().equals(p) ;
		Predicate<GameElement> isDoor = g -> g instanceof Door && g.getPosition().equals(p);
		
		if(!lr.isElement(isWall) && !lr.isElement(isMonster) && !lr.isElement(isDoor) ){		// quando a posicao a movimentar nao e monstro nem parede nem porta
			setPosition(p);
			
			lr.pickItems( pickItem(p, lr));	
			if(isPoison) {																		// se tiver envenenado recebe dano
				recieveDamage(poisondmg);
			}
		}
		else if(lr.isElement(isMonster)) {														// se na posicao a movimentar estiver um monstro o heroi da dano
			lr.giveDamage(this.damage, p);	
		}
		else if(lr.isElement(isDoor)) {															// se for porta
			Door d = lr.getDoor(p);
			interactDoor(d, Vector);															
			

			if(isPoison) {																		
				recieveDamage(poisondmg);
			}
		}
		
	}
	
	private void interactDoor(Door d, Vector2D v) {
		
		if(!d.isOpen() && !inv.hasKey(d.getId())) {					
			
			return;
		}
		else if( !d.isOpen() && inv.hasKey(d.getId())) {				// se a porta estiver fechada e o heroi tiver uma chave com o mesmo id da porta
			d.setOpen();
			inv.updateSelected2();										
			inv.use();													// consome a chave e faz update ao inventario
			inv.updateSelected();
		}
		
		doorOpen(d, v);
	}
	
	
	public void doorOpen(Door d, Vector2D v) {
		Jogo j = Jogo.getInstance();
		String s = d.getNextRoom();
		j.changeRoom(s);												// muda de sala
		
		Point2D pc = d.getNextRoomPos();			
		this.setPosition(pc);					
		this.setPosition(getPosition().plus(v));
		LoadRoom lr  = Jogo.getInstance().getLr();
		lr.getDoor(pc).setOpen();										// abre a porta
		
	}
	
		
	private List<Item> pickItem(Point2D p, LoadRoom lr) {
		List<Item> items = new ArrayList<>();
		
		for(GameElement i: lr.getElements()) {	
			if(i instanceof Item && i.getPosition().equals(p)) {	// tenta apanhar para todos os items na posicao
				if(!inv.isFull()) {									// confere se o inventario tem espaco
					inv.addItem(((Item) i));						// apanha o item que esta na posicao
					items.add(((Item) i));
					inv.updateInventoryGUI();						// da update a gui do inventario
					inv.updateSelected();
					checkStatItem();								// modifica as stats se tiver apanhado um item para tal
				}
			}
		}
		
		return items;
	}
	
	
	
	public void dropItem() {
		LoadRoom lr = Jogo.getInstance().getLr();
		Item i = inv.getCurrentItem();
		
		if(i != null) {												// verifica se o inventario esta vazio
			i.setPosition(this.getPosition());
			i.setDropped();											
			inv.removeItem(i);		
			lr.addDroppedItem(i);
			inv.updateInventoryGUI();								// da update ao inventario e as stats
			checkStatItem();
		}
	}
	
	public void use() {
		if(inv.getCurrentItem() instanceof HealingPotion) {
			if(this.getHitpoints() + 5 < 10)
				this.hitpoints = this.getHitpoints() + 5;
			else
				this.hitpoints = hp;
			
			isPoison = false;
		}
		
		inv.consume();
		
	}
	
	
	public void updateInventory(int key) {									// controles do inventario
		if(key == KeyEvent.VK_1) {
			inv.iterate();
			
		}
		else if(key == KeyEvent.VK_2) {
			inv.updateSelected2();
			dropItem();
		}
		else if(key == KeyEvent.VK_3) {
			inv.updateSelected3();
			use();
			
		}
		
		inv.updateSelected();
	}

	
	private void checkStatItem() {
		hasArmor = inv.hasArmor();
		hasSword = inv.hasSword();
		
		if(hasSword)
			this.damage = 2;
		else
			this.damage = dmg;
	}

	@Override
	public void recieveDamage(int damage) {
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
		
		if(hasArmor) {														// se tiver armadura anula dano 50% das vezes
			double random = Math.random()*2;
			
			if(random > 1) 
				super.recieveDamage(damage);
		}	
		else 												
			super.recieveDamage(damage);
		
		if(isDead())
			gui.removeImage(this);

		if(this.getHitpoints() <= 0)
			this.hitpoints = 0;
	}
	
	
	public void setPoison() {
		isPoison = true;
	}
	
	public void remPoison() {
		isPoison = false;
	}
	
	
	public Inventory getInv() {
		return inv;
	}
	
	public void stolen(Item i) {										// quando thief rouba o item
		inv.updateSelected2();
			
		inv.removeItem(i);
		inv.updateSelected();
	}
	
	
	
	
}
