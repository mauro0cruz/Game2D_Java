package Elements;
import Others.GameElement;
import Others.Monster;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Bat extends Monster {
	
	static private int hp = 3;
	static private final int dmg = 1;
	static private final int score = 5;

	static final int layer = 4;
	
	public Bat(Point2D position) {
		super(position, hp, dmg);
	}
	
	@Override
	public int getLayer() {
		return layer;
	}

	@Override
	public String getName() {
		return "Bat";
	}

	@Override
	public Direction getDirection(GameElement g) {
		double random = Math.random();
		
		if(random <= 0.5) {								// move-se numa posicao aleatoria 50% das vezes
			return Direction.random();
		}
		
		return super.getDirection(g);
	}
	
	@Override
	protected void giveDamage(Point2D p, Hero h) { 
		double random = Math.random();
		
		if(random <= 0.5) {								// da dano e regenera vida 50% das vezes
			super.giveDamage(p, h);
			if(hp < 3)
				hp = hp + 1;
			
		}
	}

	@Override
	public int getScore() {
		return score;
	}
	
	
}
