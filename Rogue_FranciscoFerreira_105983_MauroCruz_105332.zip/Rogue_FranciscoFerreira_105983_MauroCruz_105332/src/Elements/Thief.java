package Elements;

import Others.GameElement;
import Others.Inventory;
import Others.Item;
import Others.Monster;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Thief extends Monster{
	
	static private final int hp = 5;
	static private final int dmg = 0;
	static private final int score= 3;
	
	
	static final int layer = 3;
	
	private Inventory invThief;

	public Thief(Point2D position) {
		super(position, hp, dmg);
		invThief = new Inventory();
	}
	

	@Override
	public int getLayer() {
		return layer;
	}

	@Override
	public String getName() {
		return "Thief";
	}
	
	public void stealItem(Point2D p, Hero h) {
		
		if(h.getPosition().equals(p)) {
			if(!h.getInv().isEmpty()) {
				Item i = h.getInv().getRandomItem();			// recebe um item aleatorio do inventario do heroi
				invThief.addItemThief(i);						// rouba o item e adiciona ao seu inventario
				h.stolen(i);
			}
		}	
	}
	
	@Override
	public Direction getDirection(GameElement g) { 
	
		if(!invThief.isEmpty())									// quando ja tiver roubado o heroi move-se na direcao contraria ao heroi
			return super.getDirection(g).opposite();
	
		return super.getDirection(g);
	}
	
	@Override
	protected void giveDamage(Point2D p, Hero h) {
		stealItem(p, h);
		
	}
	
	

	public Item thiefDrop() {									// dropa o item que roubou
		Item i = invThief.getCurrentItem();
		
		if(i != null) {
			i.setPosition(this.getPosition());
			i.setDropped();
		
		}
		return i;
	}
	
	@Override
	public int getScore() {
		return score;
	}
	

}
