package Elements;

import Others.Monster;
import pt.iscte.poo.utils.Point2D;

public class Scorpio extends Monster{

	static private final int hp = 2;
	static private final int dmg = 0;
	
	static private final int score= 6;

	
	static final int layer = 3;
	
	public Scorpio(Point2D position) {
		super(position,hp,dmg);
		
	}

	
	@Override
	public int getLayer() {
		return layer;
	}
	
	@Override
	public String getName() {
		return "Scorpio";
	}
	
	@Override
	protected void giveDamage(Point2D p, Hero h) {
		if(h.getPosition().equals(p))
			h.setPoison();
	}

	
	@Override
	public int getScore() {
		return score;
	}
}
