package Engine;

import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import Elements.Hero;
import Map.Elements.Floor;
import Others.GameElement;
import Others.HealthBar;
import Others.LoadRoom;
import Others.Monster;
import Others.Score;
import Others.TabInfo;
import pt.iscte.poo.gui.ImageMatrixGUI;
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.observer.Observed;
import pt.iscte.poo.observer.Observer;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Jogo implements Observer{
	
	public static final int GRID_HEIGHT = 11;
	public static final int GRID_WIDTH = 10;
	
	private static Jogo INSTANCE = null;
	private ImageMatrixGUI gui = ImageMatrixGUI.getInstance();
	private HealthBar hpbar;
	
	
	
	private Score score;
	private int turns;
	private LoadRoom lr;						// atributo que guarda a room atual
	private List<Integer> moveCommands = new ArrayList<>();		// controles do movimento
	private List<Integer> inventoryCommands = new ArrayList<>();	// controles do inventario
	private Hero hero;
	private List<LoadRoom> map = new ArrayList<>();			// atributo que guarda todas as rooms do jogo
	
	
	public static Jogo getInstance() {
		if (INSTANCE == null)
			INSTANCE = new Jogo();
		return INSTANCE;
	}

	private Jogo() {		
		this.hero = new Hero(new Point2D(4,4));			// inicializa heroi
		score = new Score();							// inicializa score
		gui.registerObserver(this);						
		gui.setSize(GRID_WIDTH, GRID_HEIGHT);
		gui.go();
		updateCommands();
	}

	public void start() throws FileNotFoundException {
		addBar();										
		loadMap();						
		addFloor();
		startRoom("room0");
		gui.update();
		
	}
	
	private void addFloor() {							// adiciona o chao do da sala
		List<ImageTile> tileList = new ArrayList<>();
		for (int x=0; x!=GRID_WIDTH; x++)
			for (int y=0; y!=GRID_HEIGHT - 1; y++)
				tileList.add(new Floor(new Point2D(x,y)));
		gui.addImages(tileList);
	}

	
	private void startRoom(String room) throws FileNotFoundException{		
		for(LoadRoom r: map) {
			if(r.getRoom().equals(room)) {									// carrega a sala requerida como sala de inicializacao
				lr = r;
				gui.addImage(hero);
				lr.getElements().forEach(n -> gui.addImage(n));	
			}
		}		
	}
	
	public void changeRoom(String room) {
		lr.getElements().forEach(n -> gui.removeImage(n));					// autaliza a gui para o nova room e muda o valor da room atual
		
		for(LoadRoom r: map) {
			if(r.getRoom().equals(room)) {
				lr = r;
				lr.getElements().forEach(n -> gui.addImage(n));	
				
			}		
		}	
	}
	
	

	public LoadRoom getLr() {
		return lr;
	}
	
	public void addBar() {										// adiciona a gui a barra de vida do heroi
		for(int i = 5; i < GRID_WIDTH; i++) {
			Point2D p = new Point2D(i, GRID_HEIGHT - 1);
			TabInfo ti = new TabInfo(p, "Black");
			gui.addImage(ti);
		}
		
		hpbar = new HealthBar();
	}
		
	
	public ImageMatrixGUI getGui() {
		return gui;
	}
	
	@Override
	public void update(Observed source) {
		int key = ((ImageMatrixGUI) source).keyPressed();
		
		if(inventoryCommands.contains(key)) {								// por cada tecla dos controles de teclado da update ao inventario e a barra de vida
			hero.updateInventory(key);
			gui.update();
			hpbar.updateHPBar();
			
		} else if( moveCommands.contains(key)) {
			hero.move(Direction.directionFor(key));
		
			for(GameElement g: lr.getElements()) {
				
				if(g instanceof Monster) {									// movimenta os monstros
					Direction d = ((Monster) g).getDirection(hero);
					((Monster) g).move(d);
				}
	
			}
			
			lr.cleanUpdateRoom();											
			lr.addUpdateRoom().forEach(n -> gui.addImage(n));			
			hpbar.updateHPBar();
		
			turns++;
			gui.setStatusMessage("ROGUE Starter Package - Turns:" + turns);
			gui.update();
			finish();
			
		}
	}
	
	
	public void addRoom(String room) throws FileNotFoundException{							// adiciona uma room ao mapa do jogo
		lr = new LoadRoom(room);
		map.add(lr);
	}
	
	private void updateCommands(){

		moveCommands.add(KeyEvent.VK_RIGHT);
		moveCommands.add(KeyEvent.VK_LEFT);
		moveCommands.add(KeyEvent.VK_UP);
		moveCommands.add(KeyEvent.VK_DOWN);
		inventoryCommands.add(KeyEvent.VK_1);
		inventoryCommands.add(KeyEvent.VK_2);
		inventoryCommands.add(KeyEvent.VK_3);
	}
	
	public Hero getHero() {
		return hero;
	}
	
	public void loadMap() throws FileNotFoundException{						// carrega o mapa
		addRoom("room0");
		addRoom("room1");
		addRoom("room2");
		addRoom("room3");
		
	}
	
	public Score getScore() {
		return score;
	}
	
	private void showScore() {						
		score.sumTurn(turns);
		score.calculateTotalPoints();
		gui.setMessage(score.toString());

	}
	
	
	public void finish(){										// termina o jogo 
		
		if(hero.isDead()) {
			score.setWin(false);
			showScore();
			gui.setMessage("Monsters Win");
			score.setName(gui.askUser("Enter Nickname: "));
			score.printScore("top5");
			gui.dispose();		}
		else if(hero.getInv().hasTreasure()) {
			score.setWin(true);
			showScore();
			gui.setMessage("Victory!");
			score.setName(gui.askUser("Enter Nickname: "));
			score.printScore("top5");
			gui.dispose();
		}
		
	}
}
