package Map.Elements;

import Others.GameElement;
import pt.iscte.poo.utils.Point2D;

public class Door extends GameElement{
	
	private Point2D position_dest; //final???
	private String room;
	private String id;
	
	static final int layer = 2;
	private boolean isOpen;
	

	public Door(Point2D position, String room, Point2D position_dest, String id) {
		super(position);
		this.room = room;
		this.id = id;
		this.isOpen = false;
		this.position_dest = position_dest;
		
	}
	public Door(Point2D position, String room, Point2D position_dest) {
		super(position);
		this.room = room;
		this.isOpen = true;
		this.position_dest = position_dest;
	}

	@Override
	public int getLayer() {
		return layer;
	}
	
	public String getId() {
		return id;
	}

	@Override
	public String getName() {
		if(isOpen)
			return "DoorOpen";
		
		return "DoorClosed";
	}
	
	public void setOpen() {
		this.isOpen = true;
	}
	
	public boolean isOpen() {
		return isOpen;
		
	}
	
	public String getNextRoom() {
		return this.room;
	}
	
	public Point2D getNextRoomPos() {
		return position_dest;
	}
	

}
