package Map.Elements;

import Others.GameElement;
import pt.iscte.poo.utils.Point2D;

public class Wall extends GameElement{
	
	static final int layer = 4;
	
	public Wall(Point2D position) {
		super(position);
	}


	@Override
	public int getLayer() {
		return layer;
	}

	@Override
	public String getName() {
		return "Wall";
	}
	

}
