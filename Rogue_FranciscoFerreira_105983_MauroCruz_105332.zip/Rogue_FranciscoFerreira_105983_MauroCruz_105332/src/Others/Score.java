package Others;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;	
import java.util.Scanner;

public class Score {
	
	private String name;
	private int killPoints;
	private int turnPoints;
	private int totalPoints;
	private boolean win;
	
	public Score() {
		killPoints = 0;
		turnPoints = 0;
		totalPoints = 0;
		win= false;
	}

	
	public void sumTurn(int turns) {					// calcula segundo turnos do jogador os pontos a atribuir
		if(turns <= 150) 
			turnPoints = 300 + (turns - 150);
		else if( turns <= 160) 
			turnPoints = 300 - (turns - 150);
		else if( turns <= 170) 
			turnPoints = 290 - 10 - (turns - 160)*2;
		else if(turns > 170 || turns >= 237)	
			turnPoints = 270 - (turns - 170)*4;
		else
			turnPoints = 0;
	}
	
	public void sumKill(int points) {					
		killPoints += points;
	}
	
	public int calculateTotalPoints() {
		if(!win)
			turnPoints = turnPoints / 3;
		
		totalPoints = killPoints + turnPoints + win();
		
		return totalPoints;
	}
	

	
	
	@Override
	public String toString() {
		String w = "Victory";
		if( !win )
			w = "Lose";
		
		String s = "Points from kills: +" + killPoints + "\nPoints from turns: +" + turnPoints +
				 "\n" + w + " Points: +" + win() + "\n-------------------------------------\nTotal Points: " + totalPoints;
		
		return s;
	}
	
	
	private int win() {
		return win ? 50 : 0;
	}

	
	public void setWin(boolean win) {
		this.win = win;
	}
	
	
	public void printScore(String filename) {
		File f = new File(filename + ".txt");
		try {
			List<String> scores = alterScoreTable(readFile(f));
			PrintWriter pw = new PrintWriter(f);

			int i = 0;
			while(i < 5 && i < scores.size()) {
				pw.println((i + 1) + ". " + scores.get(i));
				i++;
			}
			
			pw.close();
		} catch (FileNotFoundException e) {
			System.err.println("File not found!");
		}
	}

	
	private List<String> alterScoreTable(List<String> list) {
		List<String> listOrg = new ArrayList<>();
		list.forEach(n -> listOrg.add(n.substring(3)));
		listOrg.add(name + " " + totalPoints);
		
		listOrg.sort(new ScoreStringComparator());
						
		return listOrg;
	}
	
	
	private List<String> readFile(File f) {
		List<String> lines = new ArrayList<>();
		
		try {
			Scanner s = new Scanner(f);
			String line = "";
			while(s.hasNextLine()) {
				line = s.nextLine();
				lines.add(line);
			}
			
			s.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		return lines;
	}
	
	
	
	
	
	
	public class ScoreStringComparator implements Comparator<String>{

		@Override
		public int compare(String o1, String o2) {
			String[] val1 = o1.split(" ");
			String[] val2 = o2.split(" ");
			
			
			return Integer.parseInt(val2[1]) - Integer.parseInt(val1[1]);
		}
		
	}
	
	
	
	public void setName(String name) {
		this.name = name;
	}
}
