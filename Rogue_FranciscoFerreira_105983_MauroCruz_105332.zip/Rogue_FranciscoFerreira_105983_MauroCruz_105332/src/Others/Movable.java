package Others;

import pt.iscte.poo.utils.Direction;

public interface Movable {
	
	public void move(Direction direction);
	
}
