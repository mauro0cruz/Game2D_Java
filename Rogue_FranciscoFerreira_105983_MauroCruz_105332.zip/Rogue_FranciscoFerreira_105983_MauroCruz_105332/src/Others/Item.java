package Others;

import pt.iscte.poo.utils.Point2D;

public abstract class Item extends GameElement{
	
	boolean isPicked;		// verdadeiro quando o item e apanhado pelo heroi, caso contrario falso
	
	public Item(Point2D position) {
		super(position);
		isPicked = false;
	}
	
	public void setPicked() {
		isPicked = true;
	}
	
	public void setDropped() {
		isPicked = false;
	}
	
	public boolean isPicked() {
		return isPicked;
	}
	
	public boolean equals( Item i) {
		return this.getPosition().equals(i.getPosition()) && this.getName().equals(i.getName());
	}
	
	@Override
	public String toString() {
		return "" + this.getName() + " X="+this.getPosition().getX() + " Y=" + this.getPosition().getY();
	}
}
