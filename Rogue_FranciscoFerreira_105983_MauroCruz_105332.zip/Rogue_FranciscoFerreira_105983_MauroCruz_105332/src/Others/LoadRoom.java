package Others;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import Elements.Thief;
import Engine.Jogo;
import Map.Elements.Door;
import pt.iscte.poo.gui.ImageMatrixGUI;
import pt.iscte.poo.utils.Point2D;

public class LoadRoom{
	
	private String room;
	
	private List<GameElement> elements = new ArrayList<>();
	private List<Item> droppedItems = new ArrayList<>();
	
	public LoadRoom(String room){ 
		
		try {
			elements = ReadFile.readMap(room);
			this.room = room;
		
		}
		catch(FileNotFoundException e){
			System.err.println();
		}
	}
	
	public String getRoom() {
		return room;
	}
	

	public boolean isElement(Predicate<GameElement> p) {
		
		for(GameElement g: elements) {
				if(p.test(g))
					return true;
		}
		
		return false;
	}
	
	
	public void giveDamage(int damage, Point2D p) {						// Da dano a monstros na posicao p
		
		for(GameElement m: elements)
			if(m instanceof Monster) {
				if(m.getPosition().equals(p))
					((Monster) m).recieveDamage(damage);
			}
		
	}
	
	
	public List<GameElement> getElements() {
		return elements;
	}
	
	
	public void cleanUpdateRoom() {											// remove monstros da sala e da GUI, assim como remove items apanhados da room
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
		Score s = Jogo.getInstance().getScore();
		
		List<GameElement> cleaningService = new ArrayList<>();
		Item i = null;
		
		for(GameElement m : elements) {
			if(m instanceof Monster) {
				if(((Monster) m).isDead()) {
					s.sumKill(((Monster) m).getScore());
					if(m instanceof Thief) {
						i = ((Thief) m).thiefDrop();
						
					}
					cleaningService.add(m);
					gui.removeImage(m);
				}
			}
			else if(m instanceof Item) {
				if(((Item) m).isPicked()) {
					cleaningService.add(m);
					gui.removeImage(m);
				}
			}
		}
		
		if(i != null)
		addDroppedItem(i);
		
	
		elements.removeAll(cleaningService);
	
	}
	
	public void pickItems(List<Item> items) {										// define items dados como parametro como apanhados
		
		for(Item i : items)
			for(GameElement n : elements)
				if(n instanceof Item && ((Item) n).equals(i)) 
					((Item) n).setPicked();
										
	}
	
	
	public void addDroppedItem(Item i) {											// coloca num atributo temporariamente o item dropado
		elements.add(i);
		droppedItems.add(i);
	}
	
	public List<Item> addUpdateRoom(){												// adiciona a room items dropados pelo hero
		List<Item> i = this.getDroppedItems();
		droppedItems = new ArrayList<>();
		
		return i;
	}
	
	private List<Item> getDroppedItems() {
		return droppedItems;
	}
	
	
	public Door getDoor(Point2D p) {												// devolve elemento Door na ponto p, se nao existir uma porta no ponto p retorna null
		for(GameElement g: elements) {
			if(g instanceof Door && g.getPosition().equals(p)) {
				return ((Door) g);	
			}
				
		}
		return null;
	}
	

	public void addElements(Item i) {						
		elements.add(i);
	}
	
		
}


