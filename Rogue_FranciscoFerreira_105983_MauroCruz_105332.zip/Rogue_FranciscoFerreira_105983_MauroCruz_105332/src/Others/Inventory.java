package Others;

import java.util.ArrayList;
import java.util.List;
import Engine.Jogo;
import Items.Armor;
import Items.HealingPotion;
import Items.Key;
import Items.Sword;
import Items.Treasure;
import pt.iscte.poo.gui.ImageMatrixGUI;
import pt.iscte.poo.utils.Point2D;

public class Inventory {
	
	private List<Item> inventory = new ArrayList<>();
	
	private int it;
	private TabInfo bar;
	static private final int capacity = 3;
	
	public Inventory() {
		this.it = 0;
		Point2D p = new Point2D(Jogo.GRID_WIDTH - 4, Jogo.GRID_HEIGHT - 1);
		bar = new TabInfo(p, "Selected");
	}
	
	
	public void iterate() {					
		if(it == inventory.size() - 1 || isEmpty()) {
			it = 0;
		}
		else
			it++;
	}
	
	public void desiterate() {
		if(it != 0 ) 
			it--;
	}
	
	
	public boolean isFull() {
		return inventory.size() == capacity;
	}
	
	public boolean isEmpty() {
		return inventory.size() == 0;
	}

	
	public void addItem(Item i) {
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
			if(isEmpty()) {										//se o inventario estiver vazio adiciona o item na primeira posicao do inventario
				Point2D p = new Point2D(Jogo.GRID_WIDTH - 4 , Jogo.GRID_HEIGHT - 1);
				bar.setPosition(p);
				gui.addImage(bar);
			}
			
			inventory.add(i);
			gui.addImage(i);
			iterate();	
	}
	
	
	public void removeItem(Item i) {
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
		if(!isEmpty()) {
			gui.removeImage(i);
			inventory.remove(i);
			desiterate();
		}
	}
	
	
	public Item getCurrentItem() {							// devolve o item na "mao" do heroi
		if(isEmpty()) 
			return null;
		return inventory.get(it);
	}
	
	
	public void updateInventoryGUI() {						// faz update a gui do inventario
		int iter = 0;
		
		if(!isEmpty()) {
			for(Item i : inventory) {
				Point2D p = new Point2D(Jogo.GRID_WIDTH - 4 + (iter++), Jogo.GRID_HEIGHT - 1);
				i.setPosition(p);
			}
		}
	}
	
	
	public void updateSelected() {							// faz update ao indicador da "mao" do heroi
		
		if(isEmpty())
			return;
		else {
			bar.setPosition(getCurrentItem().getPosition());
		}
		
	}
	
	
	public void updateSelected2() {							// caso especifico para tecla 2 (drop item)
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
		
		if(inventory.size() == 1 ) {
			gui.removeImage(bar);
			
		}	
	}
		
	public void updateSelected3() {							// caso especifico para tecla 3 (use item)
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
		
		if(inventory.size() == 1 && isUsable() ) {
			gui.removeImage(bar);
		}	
	}
	
	
	public int getIt() {									// devolve o valor do iterador
		return it;
	}
	
	
	public List<Item> getInventory() {
		return inventory;
	}
	
	
	public boolean hasSword() {
		for(Item i: inventory)
			if(i instanceof Sword)
				return true;
		
		return false;
	}
	
	
	public boolean hasArmor() {
		for(Item i: inventory)
			if(i instanceof Armor)
				return true;
		
		return false;
	}
	
	
	public boolean hasKey(String ID) {						// devolve true se o inventario tiver uma chave com ID dado como paramentro, false caso contrario
		Item i = getCurrentItem();
		if(i != null)
			if(i instanceof Key && ((Key) i).getId().equals(ID))
				return true;
		
		return false;
	}
	
	
	private boolean isUsable() {							
		Item i = getCurrentItem();
		if(i instanceof HealingPotion)
			return true;
		
		return false;
	}
	
	public void use() {
		Item i = getCurrentItem();
		if(i instanceof Key) {
			removeItem(getCurrentItem());
			updateInventoryGUI();
		}
			
	}
	

	
	public void consume() {										// consome o item na "mao" se for um item consumivel
		if(isUsable()) {
			
			removeItem(getCurrentItem());
			updateInventoryGUI();
		}
	}
	
	public void print() {										// funcao de teste
		System.out.println("");
		inventory.forEach(n -> System.out.println(n));

	}
	
	
	 public Item getRandomItem() {
		 int index = (int)(Math.random()*inventory.size());
		 Item i = inventory.get(index);
		 
		 return i;
	 }
	 
	 public void addItemThief(Item i) {							// funcao especifica para adicionar item no inventario do thief, sem adicionar imagem na GUI					
		inventory.add(i);
		this.print();
		iterate();
	 }
	 
	 public boolean hasTreasure() {
		 for(Item i: inventory)
				if(i instanceof Treasure)
					return true;
			
		return false;
	}
	

}
