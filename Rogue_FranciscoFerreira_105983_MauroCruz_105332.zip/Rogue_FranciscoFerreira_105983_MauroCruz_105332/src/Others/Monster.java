package Others;

import java.util.function.Predicate;
import Elements.Hero;
import Engine.Jogo;
import Map.Elements.Door;
import Map.Elements.Wall;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public abstract class Monster extends MElement{
	
	
	@Override
	public String getName() {
		return "Monster";
	}
	
	public Monster(Point2D position, int hitpoints, int damage) {
		super(position, hitpoints, damage);
	}

	public Direction getDirection(GameElement g) {
		
		Vector2D v = Vector2D.movementVector(getPosition(),g.getPosition());
		Direction d = Direction.forVector(v);
		return d;
	}

	
	@Override
	public void move(Direction direction) {
		LoadRoom lr = Jogo.getInstance().getLr();
		Vector2D Vector = direction.asVector();
		Point2D p = getPosition().plus(Vector);
		Hero h = Jogo.getInstance().getHero();
				
		Predicate<GameElement> isWall = g -> (g instanceof Wall) && g.getPosition().equals(p);	
		Predicate<GameElement> isDoor = g -> (g instanceof Door) && g.getPosition().equals(p);
		Predicate<GameElement> isMonster = g -> (g instanceof Monster) && g.getPosition().equals(p) ;
		
		if( !lr.isElement(isWall) && !lr.isElement(isDoor) && !h.getPosition().equals(p) && !lr.isElement(isMonster) )
			this.setPosition(p);
		
		giveDamage(p, h);
	
	}
	
	
	protected void giveDamage(Point2D p, Hero h) {
		
		if(h.getPosition().equals(p))
				h.recieveDamage(damage);
	}
	
	public abstract int getScore();	// devolve o valor do score que se recebe por matar o monstro
}
