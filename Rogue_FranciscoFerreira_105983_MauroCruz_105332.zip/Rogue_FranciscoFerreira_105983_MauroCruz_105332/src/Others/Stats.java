package Others;

public interface Stats {

	public int getHitpoints();
	
	public void recieveDamage(int damage);
	
	public boolean isDead();

}
