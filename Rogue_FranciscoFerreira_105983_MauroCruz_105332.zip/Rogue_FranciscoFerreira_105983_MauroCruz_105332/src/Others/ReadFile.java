package Others;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import Elements.Bat;
import Elements.Scorpio;
import Elements.Skeleton;
import Elements.Thief;
import Elements.Thug;
import Items.Armor;
import Items.HealingPotion;
import Items.Key;
import Items.Sword;
import Items.Treasure;
import Map.Elements.Door;
import Map.Elements.Wall;
import pt.iscte.poo.utils.Point2D;

public class ReadFile {
	
	public static List<GameElement> readMap(String room) throws FileNotFoundException{
		List<GameElement> obj = new ArrayList<>();
		Scanner sc = new Scanner(new File("rooms/" + room + ".txt"));
		int x = 0;
		int y = 0;
		
		while(x < 10 && y < 10) {
			String line = sc.nextLine();
			
				for(x=0; x < 10; x++) {
					char c = line.charAt(x);
					if(c == '#') {
						Wall w = new Wall(new Point2D(x,y));
						obj.add(w);
					}
				}
				y++;
				x=0;
		}
		sc.nextLine();
		
		while(sc.hasNextLine()) {
			
			String[] line = sc.nextLine().split(",");
			
			String type = line[0];
			int arg1 = Integer.parseInt(line[1]);
			int arg2 = Integer.parseInt(line[2]);
			
			switch(type) {
			
			case "Skeleton": obj.add(new Skeleton(new Point2D(arg1, arg2)));
			break;
			
			case "Bat": obj.add(new Bat(new Point2D(arg1, arg2)));
			break;
			
			case "Thug": obj.add(new Thug(new Point2D(arg1, arg2)));
			break;
			
			case "Sword": obj.add(new Sword(new Point2D(arg1, arg2)));
			break;
			
			case "Armor": obj.add(new Armor(new Point2D(arg1, arg2)));
			break;
			
			case "HealingPotion": obj.add(new HealingPotion(new Point2D(arg1, arg2)));
			break;
			
			case "Key": obj.add(new Key(new Point2D(arg1, arg2), line[3]));
			break;
			
			case "Treasure": obj.add(new Treasure(new Point2D(arg1, arg2)));
			break;

			case "Door": 
				if(line.length == 7) {
					obj.add(new Door(new Point2D(arg1, arg2) , line[3], 
							new Point2D(Integer.parseInt(line[4]), Integer.parseInt(line[5])), line[6]));
				}else {
					obj.add(new Door(new Point2D(arg1, arg2) , line[3], 
							new Point2D(Integer.parseInt(line[4]), Integer.parseInt(line[5]))));
					
				}
				break;
			
			case "Scorpio": obj.add(new Scorpio(new Point2D(arg1, arg2)));
			break;
			
			case "Thief": obj.add(new Thief(new Point2D(arg1, arg2)));
			break;
			
			}
			
		}
		sc.close();
	
		return obj;
	}
}
