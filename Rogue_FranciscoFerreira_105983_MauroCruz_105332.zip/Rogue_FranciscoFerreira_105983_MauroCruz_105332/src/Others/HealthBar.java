package Others;

import java.util.ArrayList;
import java.util.List;

import Elements.Hero;
import Engine.Jogo;
import pt.iscte.poo.gui.ImageMatrixGUI;
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.utils.Point2D;

public class HealthBar {
	
	List<ImageTile> bar = new ArrayList<>();
	List<String> test = new ArrayList<>();
	
	public HealthBar() {										// inicializa a barra de vida toda a verde
		ImageMatrixGUI gui = Jogo.getInstance().getGui();
		
		TabInfo green;
		String name = "Green";
		
		for(int i = 0; i < 5; i++) {
			Point2D p = new Point2D(i, Jogo.GRID_HEIGHT - 1);
			green = new TabInfo(p, name);
			bar.add(green);
			test.add(name);
		}
		
		gui.addImages(bar);
	}
	
	
	public void updateHPBar() {								
		ImageMatrixGUI g= Jogo.getInstance().getGui();
		Hero h = Jogo.getInstance().getHero();
		
		double s = (double)h.getHitpoints() / 2;
		
		g.removeImages(bar);
		bar = updateCurrentHP(s);
		g.addImages(bar);
	}
	
	
	private List<ImageTile> updateCurrentHP(double s) {			// calcula as imagens e a posicao das mesmas de acordo com o hp do heroi
		List<ImageTile> test2 = new ArrayList<>();
		String name;
		
		for(int i = 5; i > 0; i--) {
			if(s < i) {
				if(s > i - 1)
					name = "RedGreen";
				else
					name= "Red";
			}
			else
				name = "Green";
			
			Point2D p= new Point2D(5 - i, Jogo.GRID_HEIGHT - 1);
			test2.add(new TabInfo(p, name));
		}
		
		return test2;
	}
}
