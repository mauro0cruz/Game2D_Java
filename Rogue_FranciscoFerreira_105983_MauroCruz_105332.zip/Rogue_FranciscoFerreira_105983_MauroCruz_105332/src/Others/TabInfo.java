package Others;

import pt.iscte.poo.utils.Point2D;

public class TabInfo extends GameElement{
	
	public static final int layer = 0;
	String name;
	
	public TabInfo(Point2D position, String name) {
		super(position);
		this.name = name;
	}

	@Override
	public int getLayer() {
		return layer;
	}

	@Override
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return name;
	}
}
