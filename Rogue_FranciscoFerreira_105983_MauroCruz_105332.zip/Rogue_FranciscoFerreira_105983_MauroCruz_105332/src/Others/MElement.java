package Others;

import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public abstract class MElement extends GameElement implements Movable, Stats{
	
	protected int hitpoints;
	protected int damage;
	
	// Interface stats
	
	public MElement(Point2D position, int hitpoints, int damage) {
		super(position);
		this.hitpoints = hitpoints;
		this.damage = damage;
	}
	
	public abstract void move(Direction direction);
	
	@Override
	public void recieveDamage(int damage) {
		this.hitpoints -= damage;
	}
	
	@Override
	public int getHitpoints() {
		return hitpoints;
	}
	
	@Override
	public boolean isDead() {
		return this.hitpoints <= 0;
		
	}
	
}
