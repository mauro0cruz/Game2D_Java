package Items;

import Others.Item;
import pt.iscte.poo.utils.Point2D;

public class HealingPotion extends Item{
	
	static final int layer = 2;
	
	public HealingPotion(Point2D p) {
		super(p);
	}
	
	@Override
	public int getLayer() {
		return layer;
	}
	
	@Override
	public String getName() {
		
		return "HealingPotion";
	}
	
}
