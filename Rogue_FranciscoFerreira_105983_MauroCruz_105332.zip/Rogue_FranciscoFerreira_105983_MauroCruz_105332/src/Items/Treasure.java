package Items;

import Others.Item;
import pt.iscte.poo.utils.Point2D;

public class Treasure extends Item {
	
	static final int layer = 2;
	
	public Treasure(Point2D p) {
		super(p);
	}
	
	@Override
	public int getLayer() {
		return layer;
	}
	
	
	@Override
	public String getName() {
		
		return "Treasure";
	}
}
