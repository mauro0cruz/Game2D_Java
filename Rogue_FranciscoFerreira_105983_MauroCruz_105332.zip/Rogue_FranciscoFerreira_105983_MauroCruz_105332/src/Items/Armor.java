package Items;

import Others.Item;
import pt.iscte.poo.utils.Point2D;

public class Armor extends Item{
	
	static final int layer = 2;
	
	public Armor(Point2D p) {
		super(p);
	}
	
	@Override
	public int getLayer() {
		return layer;
	}
	
	
	@Override
	public String getName() {
		
		return "Armor";
	}

}
